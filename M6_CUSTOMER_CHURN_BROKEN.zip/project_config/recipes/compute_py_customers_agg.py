# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
customer_final = dataiku.Dataset("customer_final")
customer_final_df = customer_final.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
customer_final_df.head

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
agg_df = customer_final_df.groupby(['StreamingTV','InternetService','MultipleLines','Churn']).count()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

py_customers_agg_df = agg_df # For this sample code, simply copy input to output


# Write recipe outputs
py_customers_agg = dataiku.Dataset("customers_agg")
py_customers_agg.write_with_schema(py_customers_agg_df)